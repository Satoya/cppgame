#ifndef __INCLUDES__
#define __INCLUDES__
#endif

#include <iostream>
#include "allegro5/allegro.h"
#include "allegro5/allegro_image.h"
#include "allegro5/allegro_audio.h"
#include "allegro5/allegro_acodec.h"
#include <stdio.h>
//#include "Bullet.cpp"
#include <math.h>
//#include <vector>
#include "Enemy.cpp"
